char s[] = "Hello";
char *p = s;  // p pointe vers 'H'

printf("%c\n", *p);     // → 'H'
printf("%c\n", *(p+1)); // → 'e'
p++;                    // p pointe maintenant vers 'e'