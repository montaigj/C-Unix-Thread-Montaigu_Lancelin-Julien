#include <stdio.h>
#include <stdint.h>

int main(void)
{
int a = 42;
float pi = 3.14;
char lettre = 'A';

printf(" a = %d \n  pi = %f \n lettre = %c\n",a ,pi, lettre);

return 0; 
}
