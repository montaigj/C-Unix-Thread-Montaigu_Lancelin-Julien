#include <stdio.h>
#include <stddef.h>

int main(void){
	int a;
	printf("%d", a);
// On souhaite entrer un nombre
	printf("\nEntrer un nombre :");
	scanf("%d\n", &a);
	printf("%d\n", a);
	return 0;

}
