#include <stdio.h>

int main(int argc, char*argv[])
{
	#ifdef DEBUG
	printf("DEBUG : %d : %s \n", __LINE__, __FILE__);
	#endif 	
return 0;
}
