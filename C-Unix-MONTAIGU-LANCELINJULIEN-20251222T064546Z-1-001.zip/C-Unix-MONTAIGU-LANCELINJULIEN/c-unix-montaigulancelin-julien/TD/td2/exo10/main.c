#define DEBUG

#ifdef DEBUG
#define LOG(msg) printf("DEBUG (%s:%d): %s\n", __FILE__, __LINE__, msg)
#endif

#include <stdio.h>

int main(void)
{
    LOG("Initialisation");

    
    LOG("Calcul terminé");
 
    
    return 0;
}