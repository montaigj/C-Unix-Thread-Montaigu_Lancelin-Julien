#include <stdio.h>

#define  PI  3.1415
#define  GRAVITE  9.81

int main(void)
{
	printf("%f,  %f \n", PI, GRAVITE);
	return 0;
}
