#include <stdio.h>

#define square(x) x*x
#define double(x) x*2

int main(void)
{
	printf("%d\n", square(3));
	printf("%d\n", double(2));
	printf("%d\n", double((3+2)));

	return 0;
}
