#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{

int a,b,c;
	printf("La valeur de a est de :");
	scanf("%d", &a);
	printf("\nLa valeur de b est de :");
	scanf("%d", &b);
	printf("\nLa valeur de c est de :");
	scanf("%d", &c);
 	int moyenne = (a+b+c)/3;
	printf("Moyenne = %.2d\n", moyenne);

}
