#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

// Compteur global pour les signaux reçus
static volatile sig_atomic_t compteur = 0;

// Handler pour SIGUSR1
static void handler_usr1(int sig) {
    // Incrémenter le compteur global
    compteur++;

    // Écrire un message minimal (write est async-signal-safe)
    const char msg[] = "Signal SIGUSR1 reçu\n";
    write(STDOUT_FILENO, msg, sizeof(msg) - 1);
}

int main() {
    struct sigaction sa;
    pid_t pid;
    int status;

    // Configuration du gestionnaire de signal
    sa.sa_handler = handler_usr1;
    sigemptyset(&sa.sa_mask);  // Aucun signal bloqué pendant l'exécution du handler
    sa.sa_flags = SA_RESTART;  // Redémarrer les appels système interrompus

    // Installer le handler pour SIGUSR1
    if (sigaction(SIGUSR1, &sa, NULL) == -1) {
        perror("Erreur sigaction");
        exit(EXIT_FAILURE);
    }

    printf("Processus parent, PID = %d\n", getpid());

    // Créer le processus fils
    pid = fork();

    if (pid == -1) {
        perror("Erreur fork");
        exit(EXIT_FAILURE);
    } else if (pid == 0) {
        // PROCESSUS FILS
        printf("Fils démarré, PID = %d, en attente de 5 signaux SIGUSR1...\n", getpid());

        // Boucler jusqu'à recevoir 5 signaux
        while (compteur < 5) {
            pause();  // Suspendre jusqu'au prochain signal
            printf("Fils: compteur = %d\n", compteur);
        }

        printf("Fils: 5 signaux reçus, terminaison\n");
        exit(0);

    } else {
        // PROCESSUS PÈRE
        printf("Père: PID du fils = %d\n", pid);

        // Attendre un peu pour que le fils soit prêt
        sleep(1);

        // Envoyer des signaux SIGUSR1 toutes les 2 secondes
        for (int i = 0; i < 5; i++) {
            printf("Père: envoi du signal %d/5\n", i + 1);
            if (kill(pid, SIGUSR1) == -1) {
                perror("Erreur kill");
                exit(EXIT_FAILURE);
            }
            sleep(2);
        }

        // Attendre la terminaison du fils
        if (wait(&status) == -1) {
            perror("Erreur wait");
            exit(EXIT_FAILURE);
        }

        if (WIFEXITED(status)) {
            printf("Père: Le fils s'est terminé normalement avec le code %d\n",
                   WEXITSTATUS(status));
        }

        printf("Père: terminaison\n");
    }

    return 0;
}