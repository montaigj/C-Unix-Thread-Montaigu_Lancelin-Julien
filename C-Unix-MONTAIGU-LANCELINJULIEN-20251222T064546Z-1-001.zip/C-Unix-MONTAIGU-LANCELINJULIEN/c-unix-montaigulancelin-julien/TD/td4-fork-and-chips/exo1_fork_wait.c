#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main()
{
    pid_t pid;
    pid_t ppid;
    int status;
    pid = fork();
    if (pid == -1)
    {
        printf(" Les processus ne sont pas fonctionnels donc il faut re essayer %ld \n", pid);
        return 0; 
    }
    if (pid ==0)
    {
        printf("Nous sommes dans le processus fils \n");
        printf("Nous sommes dans le processus fils et le pid vaut %d et la valeur du PPID est de %d\n", getpid(), getppid());        exit(42);
    }
    else 
    {
        printf("Le pid du fils est de  %d\n", pid);
        if(wait(&status))
        {
            printf(" Le processus s'est bien terminé %d \n");
        };
        return WEXITSTATUS(status);
    }
    return 0; 

}