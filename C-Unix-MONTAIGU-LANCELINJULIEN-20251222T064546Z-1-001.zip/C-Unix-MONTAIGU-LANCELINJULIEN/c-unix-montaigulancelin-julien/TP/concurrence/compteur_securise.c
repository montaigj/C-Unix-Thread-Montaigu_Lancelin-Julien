#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

static int compteur_global = 0;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void reset_compteur(void) {
    compteur_global = 0;
}

int get_compteur(void) {
    return compteur_global;
}

void* incrementeur_thread(void* arg) {
    for (int i = 0; i < INCREMENT; i++) {
       
        pthread_mutex_lock(&mutex);
        compteur_global++;  
        pthread_mutex_unlock(&mutex);
        
    }
    return NULL;
}

int executer_test(int nb_threads, int nb_increments) {
    reset_compteur();

    pthread_t* threads = malloc(nb_threads * sizeof(pthread_t));
        // Instancier un tableau de structure pour les arguments.

    // Création des threads
    for (int i = 0; i < nb_threads; i++) 
        pthread_create(&threads[i], NULL, incrementeur_thread, NULL);

    for (int i = 0; i < nb_threads; i++)
        pthread_join(threads[i], NULL);

    int resultat = get_compteur();

    // On a oublié le free
    free(threads);

    return resultat;

int main(void) {
    printf("=== Compteur Sécurisé ===\n");
        long long expected = INCREMENT*THREAD_COUNT;

    pthread_t threads[THREAD_COUNT];

    for (int i = 0; i < THREAD_COUNT; i++)
        pthread_create(&threads[i], NULL, incrementeur_thread, NULL);

    for (int i = 0; i < THREAD_COUNT; i++)
        pthread_join(threads[i], NULL);

    printf("Valeur attendue : %ld\n", expected);
    printf("Résultat final : %ld\n", compteur_global);
    printf("Différence : %ld\n", expected - compteur_global);

    return 0;
}
