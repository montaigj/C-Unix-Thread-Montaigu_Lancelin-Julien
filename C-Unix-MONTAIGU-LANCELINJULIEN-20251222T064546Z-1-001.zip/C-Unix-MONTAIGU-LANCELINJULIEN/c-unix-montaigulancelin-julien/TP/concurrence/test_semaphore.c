// Scénario 1 : Équilibré (production = consommation)
// 3 producteurs × 10 = 30 produits
// 5 consommateurs × 6 = 30 consommations

// Scénario 2 : Producteurs plus rapides
// 5 producteurs × 10 = 50 produits
// 2 consommateurs × 10 = 20 consommations

// Scénario 3 : Consommateurs plus rapides  
// 1 producteur × 50 = 50 produits
// 10 consommateurs × 10 = 100 consommations

// TODO: Implémenter ces 3 scénarios et observer les comportements

