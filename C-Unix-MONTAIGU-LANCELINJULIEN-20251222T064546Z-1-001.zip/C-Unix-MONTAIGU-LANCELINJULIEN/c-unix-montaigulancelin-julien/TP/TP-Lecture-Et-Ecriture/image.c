#include "image.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h> // Nécessaire pour fopen, fprintf, fclose, perror

// --- Fonctions de Gestion de la Mémoire ---

Image* image_create(int width, int height) {
    // 1. Allouer l'espace pour la structure Image
    Image *img = (Image *)malloc(sizeof(Image));
    if(img == NULL) {
        return NULL;
    }
    img->width = width;
    img->height = height;

    // 2. Allouer l'espace pour les pixels : width * height * 3 (R, G, B)
    size_t data_size = (size_t)width * height * 3;
    img->pixels = (unsigned char *)malloc(data_size);
    if(img->pixels == NULL) {
        free(img); // Nettoyer la structure si l'allocation des pixels échoue
        return NULL;
    }
    
    // Initialiser les pixels à 0 (noir)
    memset(img->pixels, 0, data_size);
    
    return img;
}

void image_free(Image *img) {
    if (img == NULL) return;
    // Libérer les données des pixels d'abord
    free(img->pixels);
    // Libérer la structure Image
    free(img);
}

// --- Fonctions d'Accès aux Pixels ---

void image_set_pixel(Image *img, int x, int y, unsigned char r, unsigned char g, unsigned char b) {
    if (img != NULL && x >= 0 && x < img->width && y >= 0 && y < img->height) {
        // Calcul de l'index : (y * width + x) * 3
        int index = (y * img->width + x) * 3; 
        
        img->pixels[index + 0] = r; // R
        img->pixels[index + 1] = g; // G
        img->pixels[index + 2] = b; // B
    }
}

unsigned char image_get_red(Image *img, int x, int y) {
    if (img != NULL && x >= 0 && x < img->width && y >= 0 && y < img->height) {
        int index = (y * img->width + x) * 3;
        return img->pixels[index + 0];
    }
    return 0; // Retourne 0 (noir) en cas d'erreur
}

unsigned char image_get_green(Image *img, int x, int y) {
    if (img != NULL && x >= 0 && x < img->width && y >= 0 && y < img->height) {
        int index = (y * img->width + x) * 3;
        return img->pixels[index + 1];
    }
    return 0;
}

unsigned char image_get_blue(Image *img, int x, int y) {
    if (img != NULL && x >= 0 && x < img->width && y >= 0 && y < img->height) {
        int index = (y * img->width + x) * 3;
        return img->pixels[index + 2];
    }
    return 0;
}

// --- Fonctions de Sauvegarde (Format PPM P3, texte) ---

void image_save_txt(Image *img, const char *filename) {
    if (img == NULL) return;
    
    // Ouvrir le fichier en écriture
    FILE *fp = fopen(filename, "w");

    if (fp == NULL) {
        perror("Erreur d'ouverture du fichier");
        return;
    }

    // 1. Écrire l'en-tête PPM P3 (Portable PixMap ASCII)
    // P3, Largeur, Hauteur, Valeur Max (255)
    fprintf(fp, "P3\n%d %d\n255\n", img->width, img->height);

    // 2. Écrire les données des pixels R G B
    for(int y = 0; y < img->height; y++)
    {
        for(int x = 0; x < img->width; x++)
        {
            int index = (y * img->width + x) * 3;
            
            // Écrire R G B pour le pixel courant
            fprintf(fp, "%d %d %d", 
                img->pixels[index + 0], 
                img->pixels[index + 1], 
                img->pixels[index + 2]
            );

            // Ajouter un espace/saut de ligne pour la lisibilité
            if (x < img->width - 1) {
                 fprintf(fp, " ");
            }
        }
        fprintf(fp, "\n"); // Saut de ligne après chaque rangée
    }

    fclose(fp);
}

// Les fonctions image_save_bin, image_read_txt, image_read_bin ne sont pas implémentées 
// car elles ne sont pas nécessaires pour le dégradé et impliquent des manipulations binaires/lecture.
// Leur implémentation est laissée vide ou à compléter selon votre besoin (TODOs originaux).
void image_save_bin(Image *img, const char *filename) { /* TODO: Implémenter la sauvegarde binaire (P6) */ }
Image* image_read_txt(const char *filename) { return NULL; /* TODO: Implémenter la lecture P3 */ }
Image* image_read_bin(const char *filename) { return NULL; /* TODO: Implémenter la lecture P6 */ }