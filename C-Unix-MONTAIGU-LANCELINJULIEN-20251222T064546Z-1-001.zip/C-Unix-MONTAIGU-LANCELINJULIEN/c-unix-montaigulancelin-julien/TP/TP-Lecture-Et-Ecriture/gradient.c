#include "image.h"
#include <stdio.h>
#include <stdlib.h> // Pour l'utilisation de exit() si nécessaire

int main(int argc, char *argv[]) {
    int width = 200;
    int height = 100;
    
    Image *img = image_create(width, height);

    if (img == NULL) {
        fprintf(stderr, "Erreur: Impossible de créer l'image.\n");
        return 1;
    }

    // Génération du dégradé de bleu (Noir à Gauche -> Bleu Vif à Droite)
    for(int y = 0; y < img->height; ++y)
    {
        for(int x = 0; x < img->width; ++x)
        {
            // Calcul de la valeur Bleue basée sur la position x (0 à 255)
            // On utilise (width - 1) pour s'assurer que le dernier pixel (x=199) est exactement 255.
            unsigned char blue_value;
            if (img->width > 1) {
                // Multiplier par 255.0f avant le cast (unsigned char) pour éviter la troncature à 0
                blue_value = (unsigned char)(((float)x / (img->width - 1)) * 255.0f);
            } else {
                blue_value = 255;
            }
            
            unsigned char r = 0;
            unsigned char g = 0;
            unsigned char b = blue_value;
            
            // Définir la couleur du pixel en utilisant la fonction image_set_pixel
            image_set_pixel(img, x, y, r, g, b);
        }
    }
    
    // Sauvegarde de l'image au format PPM P3
    printf("Sauvegarde de l'image %dx%d...\n", img->width, img->height);
    image_save_txt(img, "gradient.ppm");
    printf("Fichier 'gradient.ppm' créé avec succès.\n");

    image_free(img);
    return 0;
}